﻿namespace AndBank.Core.DomainObjects
{
    public interface IAggregateRoot
    {
    }
}
