﻿namespace AndBank.Process.Application.ViewModel
{
    public class SummaryViewModel
    {
        public string ProductId { get; set; } = string.Empty;
        public decimal TotalValue { get; set; }
    }
}
